<template>
  <div class="hello">
    <p v-for="(item,index) in user.list">
      id: <span>{{item.id}}</span>   
      color: <span>{{item.color}}</span>  
      name: <span>{{item.name}}</span>  
      age: <span>{{item.age}}</span>  
    </p>
  </div>
</template>

<script type="text/babel">
import { getUserList } from '@/services'
export default {
  name: 'hello',
  data () {
    return {
      user: getUserList
    }
  },
  mounted () {
    console.log(this.user.list)
  },
  methods: {

  }
}
</script>

<style lang="stylus" scoped>

</style>
